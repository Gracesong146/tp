---
  layout: default.md
  title: "Configuration guide"
---

# Configuration guide

Certain properties of the application can be controlled (e.g user preferences file location, logging level) through the configuration file (default: `config.json`).
